$ErrorActionPreference = 'Stop'
$packageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$requiredFiles = @(
  'README.md',
  'VERSION.json',
  'frontend-reference\index.html',
  'frontend-reference\api-client.reference.js',
  'contracts\openapi.yaml',
  'database\001_initial_schema_postgresql.sql',
  'docs\02-BUSINESS-RULES.md',
  'docs\06-ACCEPTANCE-TESTS.md',
  'docs\CTO-Readiness-Review.docx'
)

$missing = @()
foreach ($relativePath in $requiredFiles) {
  $fullPath = Join-Path $packageRoot $relativePath
  if (-not (Test-Path -LiteralPath $fullPath)) { $missing += $relativePath }
}
if ($missing.Count -gt 0) {
  throw ('Missing package files: ' + ($missing -join ', '))
}

$versionPath = Join-Path $packageRoot 'VERSION.json'
$version = Get-Content -LiteralPath $versionPath -Raw | ConvertFrom-Json
$referencePath = Join-Path $packageRoot 'frontend-reference\index.html'
$actualHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $referencePath).Hash
if ($actualHash -ne $version.packagedReferenceSha256) {
  throw "Reference UI checksum mismatch. Expected $($version.packagedReferenceSha256), got $actualHash"
}

$nonReferenceFiles = Get-ChildItem -LiteralPath $packageRoot -File -Recurse |
  Where-Object { $_.FullName -notlike '*\frontend-reference\index.html' }
$secretHits = $nonReferenceFiles | Select-String -Pattern 'AKfycb[A-Za-z0-9_-]{20,}|gho_[A-Za-z0-9]{20,}' -List
if ($secretHits) {
  throw ('Potential secret found outside the frozen UI reference: ' + (($secretHits.Path | Sort-Object -Unique) -join ', '))
}

$openApiPath = Join-Path $packageRoot 'contracts\openapi.yaml'
$openApiText = Get-Content -LiteralPath $openApiPath -Raw
if ($openApiText.Contains("`t")) { throw 'OpenAPI file contains tab indentation.' }
$componentDefinitions = @{
  schemas = New-Object 'System.Collections.Generic.HashSet[string]'
  parameters = New-Object 'System.Collections.Generic.HashSet[string]'
  responses = New-Object 'System.Collections.Generic.HashSet[string]'
  securitySchemes = New-Object 'System.Collections.Generic.HashSet[string]'
}
$currentSection = ''
foreach ($line in ($openApiText -split "`r?`n")) {
  if ($line -match '^  (schemas|parameters|responses|securitySchemes):\s*$') {
    $currentSection = $Matches[1]
    continue
  }
  if ($currentSection -and $line -match '^    ([A-Za-z][A-Za-z0-9]*):\s*$') {
    [void]$componentDefinitions[$currentSection].Add($Matches[1])
    continue
  }
  if ($line -match '^  [A-Za-z]' -and $line -notmatch '^  (schemas|parameters|responses|securitySchemes):') {
    $currentSection = ''
  }
}
$referenceMatches = [regex]::Matches($openApiText, '#/components/(schemas|parameters|responses|securitySchemes)/([A-Za-z][A-Za-z0-9]*)')
$missingReferences = @()
foreach ($match in $referenceMatches) {
  $section = $match.Groups[1].Value
  $name = $match.Groups[2].Value
  if (-not $componentDefinitions[$section].Contains($name)) { $missingReferences += "$section/$name" }
}
if ($missingReferences.Count -gt 0) {
  throw ('Missing OpenAPI component references: ' + (($missingReferences | Sort-Object -Unique) -join ', '))
}
$pathCount = [regex]::Matches($openApiText, '(?m)^  /v1/').Count
if ($pathCount -lt 10) { throw "OpenAPI path count is unexpectedly low: $pathCount" }

$sqlPath = Join-Path $packageRoot 'database\001_initial_schema_postgresql.sql'
$sqlText = Get-Content -LiteralPath $sqlPath -Raw
foreach ($requiredSqlToken in @('BEGIN;', 'COMMIT;', 'CREATE TABLE users', 'CREATE TABLE requests', 'CREATE TABLE interactions', 'CREATE TABLE audit_logs')) {
  if (-not $sqlText.Contains($requiredSqlToken)) { throw "SQL schema is missing: $requiredSqlToken" }
}

Write-Host "Package OK: $($version.packageName) $($version.packageVersion)"
Write-Host "Source commit: $($version.sourceCommit)"
Write-Host "Reference checksum: $actualHash"
Write-Host "OpenAPI paths: $pathCount; local component references: $($referenceMatches.Count)"
