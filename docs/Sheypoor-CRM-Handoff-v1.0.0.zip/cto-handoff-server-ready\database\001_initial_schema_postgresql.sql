-- PostgreSQL 15+
-- Review schema names, retention and extensions with the infrastructure team.
BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS citext;

CREATE SCHEMA IF NOT EXISTS crm;
SET search_path TO crm, public;

CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  legacy_id text UNIQUE,
  username citext NOT NULL UNIQUE,
  display_name varchar(150) NOT NULL,
  password_hash text NOT NULL,
  role varchar(20) NOT NULL CHECK (role IN ('admin', 'agent')),
  is_active boolean NOT NULL DEFAULT true,
  must_change_password boolean NOT NULL DEFAULT true,
  session_version integer NOT NULL DEFAULT 1 CHECK (session_version > 0),
  version integer NOT NULL DEFAULT 1 CHECK (version > 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  deleted_at timestamptz,
  deleted_by uuid REFERENCES users(id)
);

CREATE TABLE user_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash bytea NOT NULL UNIQUE,
  session_version integer NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  last_seen_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL,
  revoked_at timestamptz,
  revoke_reason varchar(200),
  ip_address inet,
  user_agent varchar(500),
  CHECK (expires_at > created_at)
);

CREATE INDEX idx_user_sessions_active
  ON user_sessions (user_id, expires_at)
  WHERE revoked_at IS NULL;

CREATE TABLE categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  legacy_id text UNIQUE,
  parent_id uuid REFERENCES categories(id),
  level smallint NOT NULL CHECK (level BETWEEN 1 AND 3),
  name varchar(200) NOT NULL,
  normalized_name varchar(200) NOT NULL,
  position integer NOT NULL DEFAULT 0 CHECK (position >= 0),
  is_active boolean NOT NULL DEFAULT true,
  version integer NOT NULL DEFAULT 1 CHECK (version > 0),
  created_by uuid REFERENCES users(id),
  updated_by uuid REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  deactivated_at timestamptz,
  CHECK ((level = 1 AND parent_id IS NULL) OR (level > 1 AND parent_id IS NOT NULL))
);

CREATE UNIQUE INDEX uq_categories_sibling_name
  ON categories (COALESCE(parent_id, '00000000-0000-0000-0000-000000000000'::uuid), normalized_name)
  WHERE is_active;

CREATE INDEX idx_categories_parent_position
  ON categories (parent_id, position, name)
  WHERE is_active;

CREATE TABLE customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  phone varchar(11) NOT NULL UNIQUE CHECK (phone ~ '^[0-9]{1,11}$'),
  display_name varchar(200),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE request_daily_sequences (
  jalali_date_prefix char(6) PRIMARY KEY CHECK (jalali_date_prefix ~ '^[0-9]{6}$'),
  last_value integer NOT NULL DEFAULT 0 CHECK (last_value >= 0),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  legacy_root_id text UNIQUE,
  request_code varchar(12) NOT NULL UNIQUE CHECK (request_code ~ '^[0-9]{9,12}$'),
  customer_id uuid NOT NULL REFERENCES customers(id),
  status varchar(20) NOT NULL CHECK (status IN ('open', 'resolved')),
  category_id uuid NOT NULL REFERENCES categories(id),
  subcategory_id uuid REFERENCES categories(id),
  leaf_category_id uuid REFERENCES categories(id),
  category_snapshot jsonb NOT NULL CHECK (jsonb_typeof(category_snapshot) = 'object'),
  customer_name_snapshot varchar(200),
  opened_by uuid NOT NULL REFERENCES users(id),
  opened_at timestamptz NOT NULL DEFAULT now(),
  resolved_by uuid REFERENCES users(id),
  resolved_at timestamptz,
  resolution_interaction_id uuid,
  version integer NOT NULL DEFAULT 1 CHECK (version > 0),
  updated_at timestamptz NOT NULL DEFAULT now(),
  deleted_at timestamptz,
  deleted_by uuid REFERENCES users(id),
  delete_reason varchar(500),
  CHECK (
    (status = 'open' AND resolved_at IS NULL AND resolved_by IS NULL)
    OR
    (status = 'resolved' AND resolved_at IS NOT NULL AND resolved_by IS NOT NULL)
  )
);

CREATE INDEX idx_requests_customer_updated
  ON requests (customer_id, updated_at DESC)
  WHERE deleted_at IS NULL;
CREATE INDEX idx_requests_status_opened
  ON requests (status, opened_at DESC)
  WHERE deleted_at IS NULL;
CREATE INDEX idx_requests_category_updated
  ON requests (category_id, updated_at DESC)
  WHERE deleted_at IS NULL;
CREATE INDEX idx_requests_resolver_resolved
  ON requests (resolved_by, resolved_at DESC)
  WHERE status = 'resolved' AND deleted_at IS NULL;

CREATE TABLE interactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  legacy_id text UNIQUE,
  request_id uuid NOT NULL REFERENCES requests(id),
  previous_interaction_id uuid REFERENCES interactions(id),
  contact_date date NOT NULL,
  customer_name_snapshot varchar(200),
  status_after varchar(20) NOT NULL CHECK (status_after IN ('open', 'resolved')),
  description text,
  agent_id uuid NOT NULL REFERENCES users(id),
  version integer NOT NULL DEFAULT 1 CHECK (version > 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  deleted_at timestamptz,
  deleted_by uuid REFERENCES users(id),
  delete_reason varchar(500),
  CHECK (status_after <> 'open' OR (description IS NOT NULL AND length(btrim(description)) > 0))
);

ALTER TABLE requests
  ADD CONSTRAINT fk_requests_resolution_interaction
  FOREIGN KEY (resolution_interaction_id) REFERENCES interactions(id);

CREATE INDEX idx_interactions_request_created
  ON interactions (request_id, created_at ASC)
  WHERE deleted_at IS NULL;
CREATE INDEX idx_interactions_agent_created
  ON interactions (agent_id, created_at DESC)
  WHERE deleted_at IS NULL;
CREATE INDEX idx_interactions_contact_date
  ON interactions (contact_date DESC, created_at DESC)
  WHERE deleted_at IS NULL;

CREATE TABLE request_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  request_id uuid NOT NULL REFERENCES requests(id),
  interaction_id uuid REFERENCES interactions(id),
  event_type varchar(80) NOT NULL,
  actor_id uuid NOT NULL REFERENCES users(id),
  details jsonb NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(details) = 'object'),
  occurred_at timestamptz NOT NULL DEFAULT now(),
  trace_id varchar(100)
);

CREATE INDEX idx_request_events_request_time
  ON request_events (request_id, occurred_at ASC);

CREATE TABLE audit_logs (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  actor_id uuid REFERENCES users(id),
  action varchar(100) NOT NULL,
  entity_type varchar(80) NOT NULL,
  entity_id uuid,
  request_id uuid REFERENCES requests(id),
  before_data jsonb,
  after_data jsonb,
  reason varchar(500),
  trace_id varchar(100),
  ip_address inet,
  user_agent varchar(500),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_audit_logs_request_time
  ON audit_logs (request_id, created_at DESC);
CREATE INDEX idx_audit_logs_entity_time
  ON audit_logs (entity_type, entity_id, created_at DESC);
CREATE INDEX idx_audit_logs_actor_time
  ON audit_logs (actor_id, created_at DESC);

CREATE TABLE idempotency_keys (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id),
  idempotency_key varchar(100) NOT NULL,
  request_fingerprint bytea NOT NULL,
  response_status integer,
  response_body jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL,
  UNIQUE (user_id, idempotency_key),
  CHECK (expires_at > created_at)
);

CREATE INDEX idx_idempotency_expiry ON idempotency_keys (expires_at);

CREATE TABLE legacy_id_map (
  entity_type varchar(40) NOT NULL,
  legacy_id text NOT NULL,
  new_id uuid NOT NULL,
  migrated_at timestamptz NOT NULL DEFAULT now(),
  source_checksum varchar(64),
  PRIMARY KEY (entity_type, legacy_id)
);

CREATE OR REPLACE FUNCTION set_updated_at_and_version()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at := now();
  NEW.version := OLD.version + 1;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_users_version
BEFORE UPDATE ON users
FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();

CREATE TRIGGER trg_categories_version
BEFORE UPDATE ON categories
FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();

CREATE TRIGGER trg_requests_version
BEFORE UPDATE ON requests
FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();

CREATE TRIGGER trg_interactions_version
BEFORE UPDATE ON interactions
FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();

CREATE OR REPLACE FUNCTION prevent_append_only_changes()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  RAISE EXCEPTION '% is append-only', TG_TABLE_NAME USING ERRCODE = '55000';
END;
$$;

CREATE TRIGGER trg_request_events_append_only
BEFORE UPDATE OR DELETE ON request_events
FOR EACH ROW EXECUTE FUNCTION prevent_append_only_changes();

CREATE TRIGGER trg_audit_logs_append_only
BEFORE UPDATE OR DELETE ON audit_logs
FOR EACH ROW EXECUTE FUNCTION prevent_append_only_changes();

CREATE OR REPLACE FUNCTION allocate_request_code(p_jalali_date_prefix char(6))
RETURNS varchar
LANGUAGE plpgsql
AS $$
DECLARE
  v_next integer;
BEGIN
  IF p_jalali_date_prefix !~ '^[0-9]{6}$' THEN
    RAISE EXCEPTION 'Invalid Jalali date prefix' USING ERRCODE = '22023';
  END IF;

  INSERT INTO request_daily_sequences (jalali_date_prefix, last_value)
  VALUES (p_jalali_date_prefix, 1)
  ON CONFLICT (jalali_date_prefix)
  DO UPDATE SET last_value = request_daily_sequences.last_value + 1,
                updated_at = now()
  RETURNING last_value INTO v_next;

  RETURN p_jalali_date_prefix ||
    CASE WHEN v_next <= 999 THEN lpad(v_next::text, 3, '0') ELSE v_next::text END;
END;
$$;

COMMENT ON FUNCTION allocate_request_code(char) IS
  'Must be called inside the same transaction that inserts the request.';
COMMENT ON TABLE request_events IS
  'Domain history shown to authorized users. Append-only.';
COMMENT ON TABLE audit_logs IS
  'Security and administrative audit trail. Append-only.';
COMMENT ON COLUMN requests.category_snapshot IS
  'Immutable category labels and identifiers captured when the request starts.';
COMMENT ON COLUMN interactions.status_after IS
  'State of the request after this interaction was applied.';

COMMIT;
