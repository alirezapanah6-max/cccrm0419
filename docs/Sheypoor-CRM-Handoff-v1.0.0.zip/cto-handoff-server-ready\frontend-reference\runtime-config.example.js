window.CRM_RUNTIME_CONFIG = Object.freeze({
  apiBaseUrl: "https://crm-api.example.internal/api",
  requestTimeoutMs: 15000,
  environment: "staging",
  buildVersion: "1.0.0",
  enableLegacyStorage: false
});

