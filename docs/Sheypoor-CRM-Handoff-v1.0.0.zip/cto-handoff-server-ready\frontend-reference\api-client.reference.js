(function(global){
  "use strict";

  const config = global.CRM_RUNTIME_CONFIG || {};
  const baseUrl = String(config.apiBaseUrl || "").replace(/\/$/, "");
  const timeoutMs = Number(config.requestTimeoutMs || 15000);

  class ApiError extends Error {
    constructor(message, status, code, details, traceId){
      super(message);
      this.name = "ApiError";
      this.status = status || 0;
      this.code = code || "UNKNOWN_ERROR";
      this.details = details || null;
      this.traceId = traceId || "";
    }
  }

  async function request(path, options){
    if(!baseUrl) throw new ApiError("آدرس سرویس تنظیم نشده است", 0, "CONFIG_MISSING");
    const controller = new AbortController();
    const timer = setTimeout(function(){ controller.abort(); }, timeoutMs);
    const requestOptions = Object.assign({
      method: "GET",
      credentials: "include",
      headers: {"Accept":"application/json"},
      signal: controller.signal
    }, options || {});
    requestOptions.headers = Object.assign({"Accept":"application/json"}, requestOptions.headers || {});
    if(requestOptions.body && typeof requestOptions.body !== "string"){
      requestOptions.headers["Content-Type"] = "application/json";
      requestOptions.body = JSON.stringify(requestOptions.body);
    }
    try{
      const response = await fetch(baseUrl + path, requestOptions);
      const contentType = response.headers.get("content-type") || "";
      const payload = contentType.indexOf("application/json") !== -1 ? await response.json() : await response.text();
      if(!response.ok){
        const problem = payload && typeof payload === "object" ? payload : {};
        throw new ApiError(problem.message || "خطا در ارتباط با سرور", response.status, problem.code, problem.details, problem.traceId);
      }
      return payload;
    }catch(error){
      if(error && error.name === "AbortError") throw new ApiError("زمان پاسخ سرور به پایان رسید", 0, "TIMEOUT");
      if(error instanceof ApiError) throw error;
      throw new ApiError("ارتباط با سرور برقرار نشد", 0, "NETWORK_ERROR");
    }finally{
      clearTimeout(timer);
    }
  }

  function query(params){
    const search = new URLSearchParams();
    Object.keys(params || {}).forEach(function(key){
      const value = params[key];
      if(value === undefined || value === null || value === "") return;
      if(Array.isArray(value)) value.forEach(function(item){ search.append(key, item); });
      else search.set(key, value);
    });
    const text = search.toString();
    return text ? "?" + text : "";
  }

  global.CrmApi = Object.freeze({
    ApiError: ApiError,
    auth: {
      login: function(data){ return request("/v1/auth/login", {method:"POST", body:data}); },
      logout: function(){ return request("/v1/auth/logout", {method:"POST"}); },
      me: function(){ return request("/v1/auth/me"); }
    },
    users: {
      list: function(params){ return request("/v1/users" + query(params)); },
      create: function(data){ return request("/v1/users", {method:"POST", body:data}); },
      update: function(id, data){ return request("/v1/users/" + encodeURIComponent(id), {method:"PATCH", body:data}); }
    },
    categories: {
      tree: function(){ return request("/v1/categories"); },
      create: function(data){ return request("/v1/categories", {method:"POST", body:data}); },
      update: function(id, data){ return request("/v1/categories/" + encodeURIComponent(id), {method:"PATCH", body:data}); }
    },
    requests: {
      list: function(params){ return request("/v1/requests" + query(params)); },
      get: function(id){ return request("/v1/requests/" + encodeURIComponent(id)); },
      create: function(data, idempotencyKey){
        return request("/v1/requests", {method:"POST", body:data, headers:{"Idempotency-Key":idempotencyKey}});
      },
      addInteraction: function(id, data, idempotencyKey){
        return request("/v1/requests/" + encodeURIComponent(id) + "/interactions", {method:"POST", body:data, headers:{"Idempotency-Key":idempotencyKey}});
      }
    },
    interactions: {
      update: function(id, data, version){
        return request("/v1/interactions/" + encodeURIComponent(id), {method:"PATCH", body:data, headers:{"If-Match":String(version)}});
      },
      remove: function(id, version){
        return request("/v1/interactions/" + encodeURIComponent(id), {method:"DELETE", headers:{"If-Match":String(version)}});
      }
    },
    customers: {
      profile: function(phone, params){ return request("/v1/customers/" + encodeURIComponent(phone) + "/profile" + query(params)); }
    },
    reports: {
      dashboard: function(params){ return request("/v1/reports/dashboard" + query(params)); },
      performance: function(params){ return request("/v1/reports/performance" + query(params)); }
    }
  });
})(window);
